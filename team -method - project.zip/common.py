import os
import random

import playsound
from sys import platform


# The name the player entered as his name
name = ""

# The title text of the game with colours
title = [
    " _____ _           \u001b[31m___  ___          _                  \u001b[0m  _____  __                  ",
    "|_   _| |          \u001b[31m|  \/  |         | |                 \u001b[0m |  _  |/ _|                 ",
    "  | | | |__   ___  \u001b[31m| .  . |_   _ ___| |_ ___ _ __ _   _ \u001b[0m | | | | |_                  ",
    "  | | | '_ \ / _ \ \u001b[31m| |\/| | | | / __| __/ _ \ '__| | | |\u001b[0m | | | |  _|                 ",
    "  | | | | | |  __/ \u001b[31m| |  | | |_| \__ \ ||  __/ |  | |_| |\u001b[0m \ \_/ / |                   ",
    "  \_/ |_| |_|\___| \u001b[31m\_|  |_/\__, |___/\__\___|_|   \__, |\u001b[0m  \___/|_|                   ",
    "                   \u001b[31m         __/ |                  __/ |\u001b[0m                             ",
    "                   \u001b[31m        |___/                  |___/ \u001b[0m                             ",
    "______         _   _____ _                      _   _____                            ",
    "| ___ \       | | /  __ \ |                    | | |_   _|                           ",
    "| |_/ /___  __| | | /  \/ |__   __ _ _ __   ___| |   | | ___ _ __ _ __ __ _  ___ ___ ",
    "|    // _ \/ _` | | |   | '_ \ / _` | '_ \ / _ \ |   | |/ _ \ '__| '__/ _` |/ __/ _ \\",
    "| |\ \  __/ (_| | | \__/\ | | | (_| | |_) |  __/ |   | |  __/ |  | | | (_| | (_|  __/",
    "\_| \_\___|\__,_|  \____/_| |_|\__,_| .__/ \___|_|   \_/\___|_|  |_|  \__,_|\___\___|",
    "                                    | |                                              ",
    "                                    |_|                                              ",
]

# The failure text of the game with colours
failure = [
    "__   __            _                      \u001b[31m  __      _ _          _ _ \u001b[0m ",
    "\ \ / /           | |                     \u001b[31m / _|    (_) |        | | |\u001b[0m ",
    " \ V /___  _   _  | |__   __ ___   _____  \u001b[31m| |_ __ _ _| | ___  __| | |\u001b[0m ",
    "  \ // _ \| | | | | '_ \ / _` \ \ / / _ \ \u001b[31m|  _/ _` | | |/ _ \/ _` | |\u001b[0m ",
    "  | | (_) | |_| | | | | | (_| |\ V /  __/ \u001b[31m| || (_| | | |  __/ (_| |_|\u001b[0m ",
    "  \_/\___/ \__,_| |_| |_|\__,_| \_/ \___| \u001b[31m|_| \__,_|_|_|\___|\__,_(_)\u001b[0m "
]

# The success text of the game with colours
success = [
    " __   __             __                      _   _   _                                    _                    _",
    " \ \ / /            / _|                    | | | | | |                                  | |                  | |",
    "  \ V /___  _   _  | |_ ___  _   _ _ __   __| | | |_| |__   ___   _ __ ___  _   _ _ __ __| | ___ _ __ ___ _ __| |",
    "   \ // _ \| | | | |  _/ _ \| | | | '_ \ / _` | | __| '_ \ / _ \ | '_ ` _ \| | | | '__/ _` |/ _ \ '__/ _ \ '__| |",
    "   | | (_) | |_| | | || (_) | |_| | | | | (_| | | |_| | | |  __/ | | | | | | |_| | | | (_| |  __/ | |  __/ |  |_|",
    "   \_/\___/ \__,_| |_| \___/ \__,_|_| |_|\__,_|  \__|_| |_|\___| |_| |_| |_|\__,_|_|  \__,_|\___|_|  \___|_|  (_)"
]

# Genders
genders = [
    "male",
    "female"
]

# Male names
male_names = [
    "Oliver",
    "Alexander",
    "Anthony",
    "Simon Reuben",
    "Richard Matthews",
    "Christopher Lee",
    "Thomas Brown",
    "James Moriarty",
    "Elliot",
    "Henry",
    "William Huber",
    "Frank Bush",
    "Edward Bird",
    "George",
    "James",
    "Arthur",
    "Thomas Hanson",
    "Albert Simmons",
    "Peter Murray",
    "Harry"
]

# Female names
female_names = [
    "Frances",
    "Isabelle Howard",
    "Mary",
    "Olivia",
    "Veronica Holborne",
    "Hazel",
    "Elizabeth",
    "Irene Wilson",
    "Sylvia Turner",
    "Victoria",
    "Dorothy Hobb",
    "Margaret Stein",
    "Florence",
    "Barbara",
    "Anna Carbrera",
    "Ruth Newton",
    "Edna",
    "Minnie Wilkins",
    "Clara",
    "Emma"
]

# Male titles
male_titles = [
    "Mister",
    "Master",
    "Sir"
]

# Female titles
female_titles = [
    "Lady",
    "Mrs",
    "Miss"
]

# Our names for credits
credit_names = [
    "Muhammad",
    "Kaylem",
    "Cameron",
    "Manny"
]

# Randomize the order of the names
random.shuffle(credit_names)

# List containing all of the names used in the scenarios to avoid repeats
used_names = []
nssound = None

# Gets a random name, if no title or gender is specified, random ones are substitutede
def get_name(title, gender):
    # Default gender codes is -1 meaning that none is specified
    gender_code = -1

    # Attempt to convert the inputted gender to gender copde
    for i in range(len(genders)):
        if genders[i] == gender:
            gender_code = i
            break

    # Generate a random gender code (0 for male or 1 for female) if none is specified
    if gender_code == -1:
        gender_code = random.randint(0, 1)

    # Generate a random title if none is specified keeping the gender in mind
    if title == "":
        if gender_code == 0:
            title = male_titles[random.randint(0, len(male_titles) - 1)]

        else:
            title = female_titles[random.randint(0, len(female_titles) - 1)]

    # Generate a random name keeping the gender in mine
    name = ""

    # Do NOT allow duplicates so make sure the name is not in the used names list before continuing
    while name == "" or used_names.count(name) > 0:
        if gender_code == 0:
            name = male_names[random.randint(0, len(male_names) - 1)]

        else:
            name = female_names[random.randint(0, len(female_names) - 1)]

    # Put the name onto the used name list
    used_names.append(name)

    # Return the full name which is title and name concatenated 
    return title + " " + name

def print_title():
    for line in title:
        print(line)

def print_failure():
    for line in failure:
        print(line)

def print_success():
    for line in success:
        print(line)

def print_empty_line():
    print()

def get_prompt_input(question, prompt, options):
    print(question)

    # Create a new lost, options_lower, containing everything from options but to the lower case
    options_lower = []
    for option in options:
        options_lower.append(option.lower())

    # Print options
    for i in range(len(options)):
        print("{0}) {1}".format(i, options[i]))
    
    print_empty_line()

    # Loop indefinitely
    while True:
        # Get input from the user as a string
        string_input = input(prompt)

        # Check if the string is a number, if it is not go back to the start of the loop
        if not string_input.isdigit():
            # If the string input is not a number we can try compare it to a prompt and guess what the user wanted to do...
            if options_lower.count(string_input.lower()) > 0:
                return options_lower.index(string_input.lower())
            
            else:
                continue

        # Convert the string input into an integer
        int_input = int(string_input)

        # Check if the int input is in the range specified (0-max), if it is not go back to the start of the loop
        if int_input < 0 or int_input >= len(options):
            continue

        # Return what the user inputted as an integer
        return int_input

def wait_for_player():
    input("press enter to continue...")

def clear_terminal():
    if platform == "win32":
        os.system("cls")

    else:
        os.system("clear")

def print_credits():
    print_empty_line()
    print(">>> Game Devloped by Team Method <<<")

    for names in credit_names:
        print(names)
    
    # Creator of the mp3 we use
    print("Sound by David Fesliy https://www.fesliyanstudios.com")

def play_sound():
    global nssound
    nssound = playsound.playsound("worldtrouble.mp3", False)

def stop_sound():
    # Uses Apples AppKit nssound to stop the audio.
    # While playsound provides helpers for playing sound, it has no way to stop audio. I had to hack this together myself
    global nssound
    if nssound != None:
        # nssound.stop()

    nssound = None