import time
import random
import art

import common

intro1 = "28ᵗʰ February 1971,"
intro2 = "Lord Farquaad is dead - murdered!"
intro3 = "You are inspector {0} from Scotland Yard and have been called in to investigate this grisly deed."
intro4 = "Lord Farquaad was found this morning by his cook, Mrs Veronica Holborne, in the study at Red Chapel Terrace, the late Lord's residence."
intro5 = "The estimated time of death was 10:00 this morning. Your deputies have compiled a list of suspects:"
intro6 = "Your objective is to look around the residence and find clues to solve the murder of Lord Farquaad!"

suspects = [
    common.get_name("", "female"),
    common.get_name("", "female"),
    common.get_name("", "male"),
    common.get_name("", "female"),
    common.get_name("Doctor", "male"),
    common.get_name("", "female"),
    common.get_name("", "male")
]

key_messages = [
    "This key is finely decorated and clearly ornamental.",
    "This key is small, likely not meant for outdoor use.",
    "A large, hardy key. For prolonged, outdoor use."
]

# Get the names of each of the characters before we randomize
murderer = suspects[6]
wife = suspects[0]
daughter = suspects[1]
daughtersfiance = suspects[2]
cook = suspects[3]
doctor = suspects[4]
maid = suspects[5]
son = suspects[6]

# Randomize the list
random.shuffle(suspects)

# Get the new index of the murderer after we randomize so guess_murderer can still function (which is dependant upon the indices)
murderer_index = suspects.index(murderer)
selected_key = -1

def play():
    common.clear_terminal()
    print_intro()

    common.stop_sound()

    common.clear_terminal()
    searching_hallway()

def print_intro():
    art.print_start_sherlockdifficulty()

    common.print_title()
    common.print_empty_line()

    time.sleep(2)
    print(intro1)

    common.print_empty_line()
    time.sleep(1)
    print(intro2)

    time.sleep(1)
    print(intro3.format(common.name))

    time.sleep(1)
    print(intro4)

    time.sleep(1)
    print(intro5)
    common.print_empty_line()

    time.sleep(1.7)
    for suspect in suspects:
        time.sleep(0.3)
        print(suspect)

    common.print_empty_line()

    time.sleep(1.5)
    print(intro6)
    common.wait_for_player()
    common.clear_terminal()

def search_room(room):
    if room == "hallway":
        searching_hallway()

    elif room == "stairwell":
        searching_stairwell()

    elif room == "kitchen":
        searching_kitchen()

    elif room == "livingroom":
        searching_livingroom()

    elif room == "bedroom":
        searching_bedroom()

    elif room == "bathroom":
        searching_bathroom()
    
    elif room == "daughtersbedroom":
        searching_daughterbedroom()

    elif room == "daughterbedroom":
        searching_daughterbedroom()

def searching_hallway():
    common.clear_terminal()
    print("You find yourself in the hallway, it's dark and cold and there is a odd smell coming from the room to your right.")
    print("There is also a shredded letter by a box of keys on a foyer table to your near right.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to Living Room",
        "Go to Kitchen (to the right)",
        "Go up the stairs",
        "Investigate ripped letter",
        "Investigate box of keys"
    ])

    if intent_code == 0:
        guess_murderer("hallway")
    
    elif intent_code == 1:
        searching_livingroom()

    elif intent_code == 2:
        searching_kitchen()

    elif intent_code == 3:
        searching_stairwell()

    elif intent_code == 4:
        investigate_debtletter()

    else:
        investigate_keybox()

def searching_stairwell():
    common.clear_terminal()
    print("You find yourself at the top of the stairwell, there are two doors to your left and one to your right.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to hallway",
        "Go to bathroom",
        "Go to bedroom",
        "Go to daughter's bedroom"
    ])
    
    if intent_code == 0:
        guess_murderer("stairwell")
        
    elif intent_code == 1:
        searching_hallway()
    
    elif intent_code == 2:
        searching_bathroom()
    
    elif intent_code == 3:
        searching_bedroom()
    
    else:
        searching_daughterbedroom()

def searching_kitchen():
    common.clear_terminal()
    print("You are now in the kitchen, where Mrs Holborne cooks for the family, there is an opened letter on a work surface as well as the late Lord's body.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to hallway",
        "Investigate opened letter",
        "Investigate body"
    ])

    if intent_code == 0:
        guess_murderer("kitchen")

    elif intent_code == 1:
        searching_hallway()

    elif intent_code == 2:
        investigate_openedletter()

    else:
        investigate_body()

def searching_livingroom():
    common.clear_terminal()
    print("You are now in the living room, it's as if nothing happened. A deputy has kindly placed witness statements ")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to hallway",
        "Investigate police statements",
        "Investigate call log"
    ])
    
    if intent_code == 0:
        guess_murderer("livingroom")
        
    elif intent_code  == 1:
        searching_hallway()
    
    elif intent_code== 2:
        investigate_policestatement()
    
    else:
        investigate_calllog()    

def searching_bedroom():
    common.clear_terminal()
    print("You are now in the victim's bedroom. The maid has obviously just been in here. There are documents on both of the nightstands by the bed.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to stairwell",
        "Investigate wife's journal",
        "Investigate Lord's will"
    ])

    if intent_code == 0:
        guess_murderer("bedroom")

    elif intent_code == 1:
        searching_stairwell()

    elif intent_code == 2:
        investigate_wifejournal()

    else:
        investigate_will()

def searching_bathroom():
    common.clear_terminal()
    print("You are now in the victim's bathroom. There is malicious and metallic odour. The sink appears to be splattered in blood and the bin has been disturbed.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to stairwell",
        "Investigate sink",
        "Investigate bin"
    ])

    if intent_code == 0:
        guess_murderer("bathroom")
    
    elif intent_code == 1:
        searching_stairwell()
        
    elif intent_code == 2:
        investigate_sink()
    
    else:
         investigate_bin()

def searching_daughterbedroom():
    common.clear_terminal()

    if not selected_key == 2:
        print("The door is locked, it has a noteably large keyhole.")

        common.wait_for_player()
        searching_stairwell()

    print("You have entered the daughter's sleeping quarters. The chaos of the rest of the house seems distant here.")
    print("There are letters and a red speckled box on her night stand.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to stairwell",
        "Investigate opened letters",
        "Investigate red speckled box"
    ])

    if intent_code == 0:
        guess_murderer("daughterbedroom")

    elif intent_code == 1:
        searching_stairwell()

    elif intent_code == 2:
        investigate_daughtersletters()

    else:
        investigate_redbox()

def investigate_debtletter():
    common.print_empty_line()
    art.print_rippedletter()
    common.print_empty_line()
    common.print_empty_line()

    print("It seems the letter has been torn into piecies. Likely in an attempt to hide its contents.")
    print("However, you can make out the letter to say:")
    print("You owe the sum of £100,000, failure to pay will result in 20 years imprisonment.")
    common.wait_for_player()
    search_room("hallway")

def investigate_wifejournal():
    common.print_empty_line()
    art.print_journal()
    common.print_empty_line()
    common.print_empty_line()

    print("You pick up the journal, inside are notes from {0}, the late Lord's widow:".format(wife))
    common.print_empty_line()

    print("Theregross and indecent familiarity between the Lord and {0}".format(maid))
    common.wait_for_player()
    search_room("bedroom")

def investigate_will():
    common.print_empty_line()
    art.print_document()
    common.print_empty_line()
    common.print_empty_line()
    
    print("Inside the will you notice the Lord has left a portion of his great wealth to his maid, {0}.".format(maid))
    common.wait_for_player()
    search_room("bedroom")

def investigate_keybox():
    common.print_empty_line()
    art.print_keybox()
    common.print_empty_line()
    common.print_empty_line()

    print("A box with ten or so assorted keys.")
    common.print_empty_line()

    global selected_key
    previous_key = 0

    while True:
        print("You pick up a random key...")

        # Generate random number from 0-2 (3 options)
        random_key = random.randint(0, 2)
        previous_key == random_key

        # Do not allow duplicates - you can't pick up the same key twice
        if random_key == selected_key or previous_key == random_key:
            continue

        # Print the key's corresponding message
        print(key_messages[random_key])

        common.print_empty_line()
        intent_code = common.get_prompt_input("Would you like to take this key?", "", [
            "Yes",
            "No",
            "Cancel"
        ])

        if intent_code == 0:
            selected_key = random_key
            break

        elif intent_code == 1:
            continue
    
        else:
            break

    searching_hallway()

def investigate_openedletter():
    common.print_empty_line()
    art.print_openedletter()
    common.print_empty_line()
    common.print_empty_line()

    print("22ᶮᵈ February 1932,")
    print("Red Chapel Terrace,")
    print("London,")
    common.print_empty_line()
    common.print_empty_line()
    print("Dear Lord Farquad,")
    print("Please come into the practice to collect your prescription for food poisoning.")
    common.print_empty_line()
    print("Your's truly, Doctor Richard Matthews.")
    common.wait_for_player()
    search_room("kitchen")

def investigate_body():
    common.print_empty_line()
    art.print_body()
    common.print_empty_line()
    common.print_empty_line()

    print("The late Lord's body has heavy bruises around his neck and face.")
    print("His face is severely disfigured... This suggests a savage beating.")
    common.wait_for_player()
    search_room("kitchen")

def investigate_policestatement():
    common.print_empty_line()
    art.print_statements()
    common.print_empty_line()
    common.print_empty_line()

    print("You read the alibis in the prepared police statement, it reads:")
    print("{0} claims she was at a friend's house after an argument with the Lord.".format(wife))
    print("{0} claims she was at theatre with her fiance.".format(daughter))
    print("{0} claims to have also been with his fiance at a theatre.".format(daughtersfiance))
    print("{0} claims she was on her day off.".format(cook))
    print("{0} claims he was working at the time.".format(doctor))
    print("{0} claims she was working on the day and happened upon the victim's body.".format(maid))
    print("{0} claims he was attending a business meeting, he also noted a suspicion of the maid.".format(son))
    common.print_empty_line()
    print("Due to the recency of the incident, none of these have been neither confirmed nor contradicted.")
    common.wait_for_player()
    search_room("livingroom")

def investigate_calllog():
    common.print_empty_line()
    art.print_wallphone()
    common.print_empty_line()
    common.print_empty_line()

    print("The call log shows 3 recent calls from the Doctor's office.")
    print("There are also 7 missed calls from {0}".format(son))
    common.wait_for_player()
    search_room("livingroom")

def investigate_daughtersletters():
    common.print_empty_line()
    art.print_openedletter()
    common.print_empty_line()
    common.print_empty_line()

    print("The letter indicates the daughter's fiance, {0}, is unhappy about recieving no financial support over the years...".format(daughtersfiance))
    common.wait_for_player()
    search_room("daughtersbedroom")

def investigate_redbox():
    common.print_empty_line()
    art.print_redbox()
    common.print_empty_line()
    common.print_empty_line()

    print("Upon closer investigation the red marks happen to be {0}'s red lipstick and blusher...".format(daughter))
    common.wait_for_player()
    print("The box contains mirrors and other makeup accessories.")
    common.wait_for_player()
    search_room("daughtersbedroom")

def investigate_sink():
    common.print_empty_line()
    art.print_sink()
    common.print_empty_line()
    common.print_empty_line()

    print("There are small specs of blood on the outer rim of the sink.")
    print("Its apparent someone has washed thier hands quite recently.")
    common.wait_for_player()
    search_room("bathroom")

def investigate_bin():
    common.print_empty_line()
    art.print_tie()
    common.print_empty_line()
    common.print_empty_line()

    print("After rummaging through the bin and you find a bloodied tie pushed to the bottom.")
    print("This must be the main source of the horrid metallic smell you noticed earlier.")
    common.wait_for_player()
    search_room("bathroom")

def victory():
    common.clear_terminal()
    
    art.print_caught_murderer()
    common.print_success()
    common.print_credits()

def punish_player(room, name):
    common.clear_terminal()
    art.print_fired()

    common.print_failure()
    common.print_empty_line()

    intent_code = common.get_prompt_input("Would you like to play again?", "", [
        "Yes",
        "No"
    ])

    if intent_code == 0:
        play()

    else:
        print("Thank you for playing!")

def guess_murderer(room):
    options = [
        "Nevermind..."
    ]

    options.extend(suspects)
    intent_code = common.get_prompt_input("Who do you think the murderer is? ", "I think it's: ", options)

    if intent_code == 0:
        search_room(room)

    elif intent_code == murderer_index + 1:
        victory()

    else:
        punish_player(room, suspects[intent_code - 1])