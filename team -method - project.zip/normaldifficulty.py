import time
import random
import art

import common

got_key = False
incorrect_guesses = 0
collected_clues = []

intro1 = "28ᵗʰ February 1932,"
intro2 = "Lord Farquaad is dead - murdered!"
intro3 = "You are inspector {0} from Scotland Yard and have been called in to investigate this grisly deed."
intro4 = "Lord Farquaad was found this morning by his cook, Mrs Veronica Holborne, in the living room at Red Chapel Terrace, the late Lord's residence."
intro5 = "The estimated time of death was 10:00 this morning. Your deputies have compiled a list of suspects:"
intro6 = "Your objective is to look around the residence and find clues to solve the murder of Lord Farquaad!"

suspects = [
    common.get_name("", "female"),
    common.get_name("", "female"),
    common.get_name("", "male"),
    common.get_name("", "female"),
    common.get_name("Doctor", "")
]

# Get the names of each of the characters before we randomize
murderer = suspects[0]
wife = suspects[0]
daughter = suspects[1]
daughtersfiance = suspects[2]
cook = suspects[3]
doctor = suspects[4]

# Randomize the list
random.shuffle(suspects)

# Get the new index of the murderer after we randomize so guess_murderer can still function (which is dependant upon the indices)
murderer_index = suspects.index(murderer)

def play():
    global got_key
    global incorrect_guesses

    got_key = False
    incorrect_guesses = 0

    common.clear_terminal()
    print_intro()

    common.stop_sound()

    common.clear_terminal()
    searching_hallway()

def print_intro():
    art.print_start_deafultdifficulty()

    common.print_title()
    common.print_empty_line()

    time.sleep(2)
    print(intro1)

    common.print_empty_line()
    time.sleep(1)
    print(intro2)

    time.sleep(1)
    print(intro3.format(common.name))

    time.sleep(1)
    print(intro4)

    time.sleep(1)
    print(intro5)
    common.print_empty_line()

    time.sleep(1.7)
    for suspect in suspects:
        time.sleep(0.3)
        print(suspect)

    common.print_empty_line()

    time.sleep(1.5)
    print(intro6)
    common.wait_for_player()
    common.clear_terminal()

def search_room(room):
    if room == "hallway":
        searching_hallway()

    elif room == "stairwell":
        searching_stairwell()

    elif room == "kitchen":
        searching_kitchen()

    elif room == "livingroom":
        searching_livingroom()

    elif room == "bedroom":
        searching_bedroom()

    elif room == "bathroom":
        searching_bathroom()

def searching_hallway():
    common.clear_terminal()
    print("You find yourself in the hallway, it's dark and cold and there is a odd smell coming from the room to your left.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to Living Room (to the left)",
        "Go to Kitchen",
        "Go up the stairs"
    ])

    if intent_code == 0:
        guess_murderer("hallway")
        
    elif intent_code == 1:
        searching_livingroom()

    elif intent_code == 2:
        searching_kitchen()

    else:
        searching_stairwell()

def searching_stairwell():
    common.clear_terminal()
    print("You find yourself at the top of the stairwell, there are doors to your left and to your right.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to hallway",
        "Go to bathroom",
        "Go to bedroom"
    ])

    if intent_code == 0:
        guess_murderer("stairwell")

    if intent_code == 1:
        searching_hallway()

    elif intent_code == 2:
        searching_bathroom()

    else:
        searching_bedroom()

def searching_kitchen():
    common.clear_terminal()
    print("You are now in the kitchen, where Mrs Holborne cooks for the family, there is a journal which seems to be the victim's and a serrated kitchen knife.")
    
    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to hallway",
        "Investigate journal",
        "Investigate kitchen knife"
    ])

    if intent_code == 0:
        guess_murderer("kitchen")

    elif intent_code == 1:
        searching_hallway()

    elif intent_code == 2:
        investigate_journal()

    else:
        investigate_kitchenknife()

def searching_livingroom():
    common.clear_terminal()
    print("You are now in the living room, you immediately find the source of the off smell, a decomposing body! There is also an opened letter on the dining table.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to hallway",
        "Investigate body",
        "Investigate opened letter"
    ])

    if intent_code == 0:
        guess_murderer("livingroom")

    elif intent_code == 1:
        searching_hallway()

    elif intent_code == 2:
        investigate_body()

    else:
        investigate_openedletter()

def searching_bedroom():
    common.clear_terminal()
    print("You are now in the Lord's sleeping quarters, as soon as you enter something does not seem right. There is a locked box under the bed and the Lord's will on the dresser.")

    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to stairwell",
        "Investigate Lord's will",
        "Investigate locked box"
    ])

    if intent_code == 0:
        guess_murderer("bedroom")

    elif intent_code == 1:
        searching_stairwell()

    elif intent_code == 2:
        investigate_will()

    else:
        investigate_lockedbox()

def searching_bathroom():
    common.clear_terminal()
    print("You are now in the victim's bathroom, the room seems to be suspiciously well kept. There is no dust to be seen which indicates it has recently been cleaned.")
    print("The cupboard has been left open and there is an open bottle of perfume.")
    
    intent_code = common.get_prompt_input("What would you like to do? ", "I want to: ", [
        "Guess murderer",
        "Go to stairwell",
        "Pick up key",
        "Investigate perfume"
    ])
    
    if intent_code == 0:
        guess_murderer("bathroom")

    elif intent_code == 1:
        searching_stairwell()

    elif intent_code == 2:
        investigate_key()

    else:
        investigate_perfume()

def investigate_journal():
    common.print_empty_line()
    art.print_journal()
    common.print_empty_line()
    common.print_empty_line()

    if collected_clues.count("journal") == 0:
        collected_clues.append("journal")

    print("You pick up the journal, inside are notes from the Lord.")
    common.print_empty_line()
    print("{0}, my dear wife, has taken a sudden interest in attending medical school.".format(wife))
    common.print_empty_line()
    print("I am no longer the Spring chicken I once was, I ought to sign and post my will to my solicitor.")
    common.print_empty_line()
    print("My wife's new perfume is hideous.")
    common.wait_for_player()
    search_room("kitchen")

def investigate_kitchenknife():
    common.print_empty_line()
    art.print_knife()
    common.print_empty_line()
    common.print_empty_line()

    if collected_clues.count("kitchenknife") == 0:
        collected_clues.append("kitchenknife")

    print("You pick up the kitchen knife, it's bloodied, {0}'s name has been engraved upon the handle...".format(cook))
    print("Perhaps she is the cook...")
    common.wait_for_player()
    search_room("kitchen")

def investigate_body():
    common.print_empty_line()
    art.print_body()
    common.print_empty_line()
    common.print_empty_line()

    if collected_clues.count("body") == 0:
        collected_clues.append("body")

    print("There seems to be surgical cuts on the victim's carotid artery, it is apparent only a professional instrument could have done this.  ")
    common.wait_for_player()
    search_room("livingroom")

def investigate_openedletter():
    common.print_empty_line()
    art.print_openedletter()
    common.print_empty_line()
    common.print_empty_line()

    if collected_clues.count("openedletter") == 0:
        collected_clues.append("openedletter")

    print("22ᶮᵈ February 1932,")
    print("Red Chapel Terrace,")
    print("London,")
    common.print_empty_line()
    common.print_empty_line()
    print("Dear Lord Farquad,")
    print("Please come into the practice to collect your prescription for food poisoning.")
    common.print_empty_line()
    print("Your's truly, {0}.".format(doctor))
    common.wait_for_player()
    search_room("livingroom")

def investigate_will():
    common.print_empty_line()
    art.print_document()
    common.print_empty_line()
    common.print_empty_line()

    if collected_clues.count("will") == 0:
        collected_clues.append("will")

    print("Inside the will you notice the Lord has left his great wealth to his daughter, {0}.".format(daughter))
    common.wait_for_player()
    search_room("bedroom")

def investigate_lockedbox():
    common.print_empty_line()
    art.print_lockedbox()
    common.print_empty_line()
    common.print_empty_line()

    if got_key:
        if collected_clues.count("lockedbox") == 0:
            collected_clues.append("lockedbox")
        
        print("There is a blood coated scalpel inside, it looks to be fresh.")
    
    else:
        print("This box is locked and will require a key to open.")

    common.wait_for_player()
    search_room("bedroom")

def investigate_key():
    common.print_empty_line()
    art.print_key()
    common.print_empty_line()
    common.print_empty_line()

    global got_key

    if collected_clues.count("key") == 0:
        collected_clues.append("key")

    print("The key is very small and odd shaped, it is clear it is not an ordinary key.")
    if got_key:
        print("You already have the key!")

    else:
        print("You have picked up the key!")

    got_key = True
    common.wait_for_player()
    search_room("bathroom")

def investigate_perfume():
    common.print_empty_line()
    art.print_perfume()
    common.print_empty_line()
    common.print_empty_line()

    if collected_clues.count("perfume") == 0:
        collected_clues.append("perfume")
    
    print("The bottle looks expensive and seems to have not been used much.")
    common.wait_for_player()
    search_room("bathroom")

def victory():
    common.clear_terminal()

    art.print_caught_murderer()
    common.print_success()
    common.print_credits()

def punish_player(room, name):
    common.print_empty_line()
    global incorrect_guesses

    if len(collected_clues) < 3:
        incorrect_guesses += 2

    else:
        incorrect_guesses += 1

    if incorrect_guesses == 1:
        print("You have falsely accused {0} of murder!".format(name))
        print("Your superiors have indicated that they will not tolerate another failure from you or your department.")
        common.wait_for_player()
        search_room(room)

    else:
        common.clear_terminal()
        art.print_fired()

        common.print_failure()
        common.print_empty_line()

        intent_code = common.get_prompt_input("Would you like to play again?", "", [
            "Yes",
            "No"
        ])

        if intent_code == 0:
            play()

        else:
            print("Thank you for playing!")

def guess_murderer(room):
    options = [
        "Nevermind..."
    ]

    options.extend(suspects)
    if len(collected_clues) < 3:
        print("\u001b[31mWARNING\u001b[0m: your superior would not appreciate you just guessing who the murderer is... If you guess incorrectly you will be suspended!")
        print("(You have less than 3 clues)")
        common.print_empty_line()

    intent_code = common.get_prompt_input("Who do you think the murderer is? ", "I think it's: ", options)
    if intent_code == 0:
        search_room(room)

    elif intent_code == murderer_index + 1:
        victory()

    else:
        punish_player(room, suspects[intent_code - 1])