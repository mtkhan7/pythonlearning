import common
import normaldifficulty
import harddifficulty

def main_menu():
    common.play_sound()
    common.print_title()
    common.print_empty_line()

    intent_code = common.get_prompt_input("Investigator {0}, what would you like to do? ".format(common.name), "I want to: ", [
        "Start game",
        "Update my name",
        "Quit game",
    ])        

    if intent_code == 0:
        common.clear_terminal()
        select_difficulty()

    elif intent_code == 1:
        common.clear_terminal()
        common.print_title()
        common.print_empty_line()
        common.name = get_name()
        main_menu()

    else: 
        print("You have quit the game!")

def select_difficulty():
    common.print_title()
    common.print_empty_line()

    intent_code = common.get_prompt_input("Investigator {0}, what do you think you're capable of? (play Sherlock Holmes if you're up for a challenge)".format(common.name), "I am: ", [
        "Normal",
        "Sherlock Holmes"
    ])

    if intent_code == 0:
        normaldifficulty.play()

    else:
        harddifficulty.play()

def get_name():
    while True:
        string_input = input("Investigator, what is your name? ")

        if len(string_input) == 0:
            continue
    
        return string_input

common.clear_terminal()
common.print_title()
common.print_empty_line()
common.name = get_name()
common.clear_terminal()

main_menu()